import { useState } from 'react';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState('dashboard');

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const menuItems = [
    {
      name: 'Clients',
      icon: 'dashboard',
    },
    {
      name: 'Services',
      icon: 'settings',
    },
    {
      name: 'Orders',
      icon: 'order',
    },
  ];

  return (
    <div className={`sidebar w-64 bg-gray-900 text-white flex flex-col px-8 py-4 h-screen ${isOpen ? 'open' : ''}`}>
      {/* <button onClick={toggleSidebar}>Toggle Sidebar</button> */}
     <div className="logo text-bold"><h4>Billingflow</h4>
     <p>HOSTING PORTAL</p>
     </div>
     <br />
      
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
    </div>
  );
};

export default Sidebar;