import './App.css';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="flex h-screen bg-gray-50">
     
     <div className="transition-all duration-300 ease-in-out flex-shrink-0">
      <Sidebar />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <div className="flex-1 overflow-x-hidden overflow-y-auto">
          <Dashboard />
        </div>
      </div>
    </div>
  );
}

export default App;
