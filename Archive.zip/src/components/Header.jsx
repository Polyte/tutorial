import { useState } from 'react';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <header className="bg-gray-800 text-white py-4">
      <div className="container mx-auto flex justify-between items-center px-8">
      <div className="flex items-center rounded-lg bg-white/5 pl-3 outline-1 -outline-offset-1 outline-white/10 focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-indigo-500">
              <div className="shrink-0 text-base text-gray-400 select-none sm:text-sm/6"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
  <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
</svg>
</div>
              <input id="search" type="text" name="username" placeholder="Search clients" className="block min-w-0 grow bg-transparent  text-base text-white placeholder:text-gray-500 focus:outline-none sm:text-sm/6" />
            </div>
        <nav className="hidden md:flex space-x-4">
          <a href="#" className="hover:text-gray-300">Home</a>
          <a href="#" className="hover:text-gray-300">About</a>
          <a href="#" className="hover:text-gray-300">Contact</a>
        </nav>
        <div className="md:hidden">
          <button onClick={toggleMenu} className="text-white focus:outline-none">
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="md:hidden">
          <nav className="mt-4">
            <a href="#" className="block py-2 px-4 hover:bg-gray-700">Home</a>
            <a href="#" className="block py-2 px-4 hover:bg-gray-700">About</a>
            <a href="#" className="block py-2 px-4 hover:bg-gray-700">Contact</a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;