const Dashboard = () => {
    return (
        <div className="dashboard px-8 py-8">
            <h1>Dashboard</h1>
            <p>Welcome to the dashboard!</p>
        </div>
    )
}

export default Dashboard;